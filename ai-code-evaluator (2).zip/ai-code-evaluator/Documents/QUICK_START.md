# AI Code Evaluator - Quick Start Guide

## 🎯 What This Extension Does

Your extension evaluates AI-generated code using Claude's API with 5 quality metrics.

---

## 3-Step Setup

### 1️⃣ Get API Key
- Go to https://console.anthropic.com
- Create API key (starts with `sk-ant-`)

### 2️⃣ Load Extension
```
chrome://extensions
→ Enable Developer Mode
→ Load unpacked
→ Select folder with files
```

### 3️⃣ Configure
- Click extension icon
- Paste API key
- Save

**Done!** You're ready to use.

---

## How It Works (User Perspective)

### Step 1: Code Detection 🔍
```
You: Ask Claude/ChatGPT to write code
↓
Extension: Automatically detects code
↓
Result: Purple "✓ Evaluate Code" button appears
```

### Step 2: Evaluate 🤖
```
You: Click "Evaluate Code" button
↓
Extension: Opens side panel
↓
Claude AI: Analyzes the code
↓
Result: Detailed evaluation appears
```

### Step 3: View Results 📊
```
You: See ratings and explanations
↓
Metrics:
  • Does it work? (Yes/No)
  • Whitespace (0-1)
  • Function Names (0-1)
  • Variable Names (0-1)
  • Comments (0-1)
  
→ Overall Score (0-1)
```

---

## File Structure

```
📦 ai-code-evaluator/
 ├── 📄 manifest.json          ← Extension config
 ├── 📝 content.js             ← Detects code (runs on web pages)
 ├── 🔌 background.js          ← Calls Claude API
 ├── 🎨 evaluator.html         ← Results display (beautiful UI)
 ├── 💻 evaluator.js           ← Results logic
 ├── ⚙️  popup.html            ← Settings interface
 ├── 🔑 popup.js               ← API key management
 └── 📚 README.md              ← Full documentation
```

---

## Evaluation Criteria Explained

### ✅ Does the Code Work? (Binary: 1 or 0)
```
✓ = Code runs without errors (1)
✗ = Code has issues/won't run (0)
```

### 📐 Whitespace & Structure (0-1)
```
0.0 ← No spacing at all
0.5 ← Some proper spacing
1.0 ← Excellent spacing, clear structure
```
**What it checks:**
- Blank lines between functions
- Proper indentation
- Logical grouping

### 🏷️ Function Names (0-1)
```
0.0 ← func(), f(), doStuff()
0.5 ← calculate(), getData()
1.0 ← calculateTotal(), fetchUserData()
```
**What it checks:**
- Clear and descriptive
- Verb-noun structure
- Avoids abbreviations

### 🔤 Variable Names (0-1)
```
0.0 ← x, y, temp, data
0.5 ← count, value, result
1.0 ← userCount, totalPrice, isActive
```
**What it checks:**
- Meaningful names
- Consistent convention
- Reflects purpose

### 💬 Comments (0-1)
```
0.0 ← No comments
0.5 ← Some comments explaining what
1.0 ← Comments explain why + function docs
```
**What it checks:**
- Function documentation
- Complex logic explanation
- No outdated comments

### 📊 Overall Readability Score (0-1)
```
Average of the 4 readability metrics:
(Whitespace + Function Names + Variable Names + Comments) ÷ 4
```

---

## Color Coding Guide

When you see progress bars in the results:

```
████░░░░░░ (0-30%)  → RED    = Needs Work
████████░░ (30-60%) → YELLOW = Average
██████████ (60-80%) → LIME   = Good
██████████ (80-100%)→ GREEN  = Excellent
```

---

## Example Result

### Code That Scores Well

**Input Code:**
```javascript
/**
 * Calculate the sum of two numbers
 */
function calculateSum(firstNumber, secondNumber) {
    return firstNumber + secondNumber;
}

/**
 * Format a price with currency symbol
 */
function formatPrice(price) {
    return '$' + price.toFixed(2);
}
```

**Results:**
```
✓ Works: YES (1)
  Reason: Code runs perfectly in console

Whitespace: 0.95 (████████░)
  Reason: Excellent spacing between functions, clear structure

Function Names: 0.98 (██████████)
  Reason: Very descriptive, follows naming conventions

Variable Names: 0.92 (█████████░)
  Reason: Meaningful names, clear purpose

Comments: 0.90 (█████████░)
  Reason: Good function documentation, explains purpose

Overall Readability: 0.94
```

---

## Example Result (Poor Code)

**Input Code:**
```javascript
function f(a,b){
return a+b;
}
function g(x){
return x*2;
}
```

**Results:**
```
✓ Works: YES (1)
  Reason: Code is syntactically correct

Whitespace: 0.20 (██░░░░░░░)
  Reason: No spacing between functions, poor formatting

Function Names: 0.15 (█░░░░░░░░)
  Reason: Single letters, unclear purpose (f, g)

Variable Names: 0.25 (██░░░░░░░)
  Reason: Non-descriptive (a, b, x)

Comments: 0.00 (░░░░░░░░░░)
  Reason: No documentation or comments

Overall Readability: 0.15
```

---

## FAQ

**Q: How do I get an API key?**
A: Visit console.anthropic.com, sign up, create an API key

**Q: Is my code private?**
A: Code is sent to Claude API for analysis. It's not logged or stored.

**Q: How much does it cost?**
A: Uses your Anthropic API credits. ~$0.01 per evaluation.

**Q: Why isn't the button showing?**
A: Make sure you're on claude.ai or chatgpt.com. Wait a moment and refresh.

**Q: Can I evaluate multiple codes?**
A: Yes! Click any "Evaluate Code" button on the page. Only one panel at a time.

**Q: What if I have an old code?**
A: You can still click "Evaluate Again" to analyze it.

---

## Common Issues & Solutions

| Problem | Solution |
|---------|----------|
| Button not appearing | Refresh page, wait 2-3 seconds |
| "API key not found" | Click extension icon, enter API key, save |
| Panel won't open | Check API key is valid in extension popup |
| Slow evaluation | Normal (2-10 sec). Check internet connection |
| No explanations shown | Reload evaluator panel |

---

## Keyboard Shortcuts

```
Click extension icon → Opens settings
Enter key in API field → Saves API key
Escape in panel → Closes panel
```

---

## Tips for Best Results

1. **Use fresh code** - Evaluate code immediately after generation
2. **Iterate** - Ask AI to improve based on feedback
3. **Track patterns** - Note which languages/patterns score well
4. **Learn conventions** - Study what makes scores high
5. **Provide context** - Give AI specific improvements to make

---

## System Requirements

- Chrome/Chromium browser
- Valid Anthropic API key
- Internet connection
- Modern JavaScript support

---

## Extension Permissions Explained

```
✓ storage        → Store your API key locally
✓ tabs           → Detect current webpage
✓ scripting      → Inject code detection on pages
✓ windows        → Open evaluation panel
```

**Security:** All data stays on your device except code sent to Claude API.

---

## Support

**Not working?** Check:
1. ✅ API key is valid (starts with `sk-ant-`)
2. ✅ Extension is loaded (appears in toolbar)
3. ✅ You're on claude.ai or chatgpt.com
4. ✅ Code actually exists in the message
5. ✅ Browser console has no errors (F12)

**Need help?** Open browser console (F12) and check for error messages.

---

## Next Steps

1. **Install** the extension
2. **Configure** your API key
3. **Generate** code from Claude/ChatGPT
4. **Click** "Evaluate Code" button
5. **Review** the results
6. **Iterate** and improve!

---

**Happy coding! 🚀**
