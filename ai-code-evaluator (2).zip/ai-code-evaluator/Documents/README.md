# AI Code Evaluator

A browser extension that detects AI-generated code inside ChatGPT and Claude, injects an “Evaluate Code” button, automatically sends an evaluation prompt into the current chat, and displays the AI’s response in a dedicated evaluator panel.

---

## ✨ Features

### 🔍 Automatic Code Detection

* Detects code blocks in ChatGPT and Claude
* Supports multiple programming languages
* Injects a purple “Evaluate Code” button

### 🤖 AI-Powered Evaluation

The extension asks the current AI model to evaluate code based on:

* Does the code work? (Expected output vs result)
* Readability (function names, variable names, whitespace, Comments)
* 

### 📊 Live Evaluator Panel

* Opens a dedicated evaluator window 
* Streams AI responses live
* Shows final evaluation result

---

## ⚙️ How It Works

```text
AI Generates Code
        ↓
Extension Detects Code
        ↓
User Clicks “Evaluate Code”
        ↓
Prompt Auto-Inserted Into Chat
        ↓
AI Evaluates Code
        ↓
Extension Captures Response
        ↓
Result Displayed in Evaluator Panel
```

---

## 📁 Core Files

```text
manifest.json      → Extension config
content.js         → Code detection + prompt injection
background.js      → Panel management
evaluator.html     → Evaluator UI
evaluator.js       → Live result rendering
popup.html/js      → Extension popup
```

---

## 🚀 Installation

1. Open chrome://extensions ( or edge://extensions)
2. Enable Developer Mode
3. Click Load unpacked
4. Select the extension folder
5. Enjoy!

---

## 🧠 Key Insight

This extension does not evaluate code itself.

It acts as a trust layer for AI-generated code

while ChatGPT or Claude performs the reasoning.

---


