# AI Code Evaluator — System Architecture

## 🎯 Core Idea

An intelligent browser extension that:

1. Detects code in AI chats
2. Injects an “Evaluate Code” button
3. Automatically sends an evaluation prompt into the current chat
4. Captures the next AI response
5. Displays results inside a dedicated evaluator panel

No direct API integration required.

The current AI model (ChatGPT or Claude) becomes the evaluator itself.

---

# 📐 System Flow

## Phase 1 — Code Detection

```text
ChatGPT / Claude Page Loads
        ↓
content.js Starts
        ↓
Scans Assistant Messages
        ↓
Detects Code Blocks
        ↓
Identifies Programming Language
        ↓
Injects “✓ Evaluate Code” Button
```

### What Happens

The extension continuously watches the DOM using a MutationObserver.

When code is detected:

* the language is identified
* a purple evaluation button is injected
* the message is marked as scanned

Supported languages include:

* Python
* JavaScript
* TypeScript
* Java
* C++
* C#
* SQL
* HTML/CSS
* Go
* Rust
* Bash

---

## Phase 2 — User Starts Evaluation

```text
User Clicks “Evaluate Code”
        ↓
Prompt Automatically Generated
        ↓
Code Copied Into Evaluation Prompt
        ↓
Evaluator Panel Opens
        ↓
Prompt Inserted Into Current Chat
        ↓
Auto Submit Triggered
```

### What Happens

The extension:

* builds a structured evaluation prompt
* inserts the prompt into ChatGPT/Claude
* presses send automatically
* opens evaluator.html as a side panel
* stores temporary state in chrome.storage.local

---

## Phase 3 — AI Response Capture

```text
AI Starts Responding
        ↓
MutationObserver Watches Chat
        ↓
Extension Detects New Assistant Message
        ↓
Streams Partial Result
        ↓
Detects Generation Finished
        ↓
Marks Evaluation Complete
```

### Key Insight

The extension does NOT evaluate code itself.

Instead:

* ChatGPT or Claude performs the evaluation
* the extension acts as:

  * orchestrator
  * prompt injector
  * response capture layer
  * visualization layer

---

## Phase 4 — Result Display

```text
Response Captured
        ↓
Stored in Chrome Storage
        ↓
evaluator.js Reads Result
        ↓
Updates UI in Real Time
        ↓
Displays Final Evaluation
```

The evaluator panel shows:

* detected language
* original code
* live AI response
* final evaluation result

---

# 🧠 System Architecture

```text
┌────────────────────────────┐
│ ChatGPT / Claude Webpage   │
└─────────────┬──────────────┘
              │
              │ content.js
              │
              ▼
      Detect Code Blocks
              │
              ▼
     Inject Evaluate Button
              │
         User Click
              │
              ▼
     Build Evaluation Prompt
              │
              ▼
   Auto Insert Into Chat Input
              │
              ▼
         Auto Submit
              │
              ▼
      AI Generates Response
              │
              ▼
    Capture Assistant Message
              │
              ▼
      evaluator.html Updates
```

---

# 📁 File Responsibilities

## manifest.json

Defines:

* permissions
* content scripts
* service worker
* popup
* accessible resources

---

## content.js

Main engine of the extension.

Responsibilities:

* detect code
* detect language
* inject buttons
* build prompts
* auto submit prompts
* monitor responses
* store evaluation state

This is the core intelligence layer.

---

## background.js

Acts as:

* service worker
* panel manager
* storage coordinator

Responsibilities:

* open evaluator window
* manage tab state
* prevent race conditions
* handle extension lifecycle

---

## evaluator.html

Dedicated evaluation UI.

Displays:

* code preview
* loading state
* live AI response
* final result

---

## evaluator.js

Handles:

* reading chrome storage
* updating UI
* reacting to storage changes
* rendering results live

---

## popup.html + popup.js

Minimal extension popup.

Purpose:

* explain how the extension works
* provide lightweight onboarding

No API key required anymore.

---

# 🔥 Key Architectural Insight

This extension is NOT:

* a static code analyzer
* a linter
* an API wrapper

It is:

> A workflow orchestration layer on top of AI chats.

The extension coordinates:

* detection
* prompting
* response extraction
* evaluation visualization

while the AI model performs reasoning.

---

# ⚡ Core Design Principles

## 1. AI-as-the-engine

The extension delegates reasoning to the current chat model.

---

## 2. Browser-native workflow

No external dashboard required.

Everything happens:

* inside ChatGPT
* inside Claude
* inside the user’s existing workflow

---

## 3. Prompt-driven evaluation

Evaluation logic is controlled entirely through prompts.

This makes the system:

* flexible
* model agnostic
* easily upgradeable

---

## 4. Real-time orchestration

The extension behaves like:

* a lightweight copilot
* a workflow automation layer
* an AI interaction enhancer

not merely a UI tool.

---

# 🚀 What You Actually Built

Not just a “code checker.”

You built:

> A trust layer for AI-generated code inside conversational AI systems.
